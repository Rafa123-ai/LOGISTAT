import streamlit as st
from ui_branding import render_header

render_header("Diésel", show_home=True)

st.info("El motor V11 ya calcula Diésel si subes el template en Planeación.")
st.write("Ve a Planeación → sube template Diésel → Ejecutar → luego revisa Dashboard/Reportes.")
