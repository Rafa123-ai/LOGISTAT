import streamlit as st
from ui_branding import render_header
import os

render_header("Exportación", show_home=True)

st.subheader("Descargas")

# Excel principal (salida del motor)
out_xlsx = st.session_state.get("out_xlsx")
if isinstance(out_xlsx, str) and os.path.exists(out_xlsx):
    with open(out_xlsx, "rb") as f:
        st.download_button(
            "⬇️ Descargar Excel (salida principal)",
            data=f,
            file_name=os.path.basename(out_xlsx),
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
            key="dl_main_xlsx",
        )
else:
    st.info("Aún no hay Excel principal. Ejecuta Planeación primero.")

# Workbook completo (todas las hojas del esquema)
full_path = st.session_state.get("out_full_export")
if isinstance(full_path, str) and os.path.exists(full_path):
    with open(full_path, "rb") as f:
        st.download_button(
            "⬇️ Descargar Excel COMPLETO (todas las hojas)",
            data=f,
            file_name=os.path.basename(full_path),
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
            key="dl_full_export",
        )
else:
    st.caption("El Excel COMPLETO se genera automáticamente al ejecutar Planeación (si existe la salida principal).")

st.divider()

# Export por hoja (descargas separadas)
sheet_exports = st.session_state.get("out_sheet_exports", {})
if isinstance(sheet_exports, dict) and sheet_exports:
    st.subheader("Descarga por hoja (archivos separados)")
    sheet = st.selectbox("Selecciona hoja a descargar", options=list(sheet_exports.keys()))
    path = sheet_exports.get(sheet)
    if isinstance(path, str) and os.path.exists(path):
        with open(path, "rb") as f:
            st.download_button(
                f"⬇️ Descargar {sheet}",
                data=f,
                file_name=os.path.basename(path),
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True,
                key=f"dl_{sheet}",
            )
else:
    st.info("Aún no hay exports por hoja. Ejecuta Planeación primero.")
