﻿from pathlib import Path
import re
from datetime import datetime

p = Path("wrap_core.py")
if not p.exists():
    raise SystemExit("No encuentro wrap_core.py. Asegúrate de estar en la carpeta LOGISTAT_BACKUP.")

src = p.read_text(encoding="utf-8", errors="replace")

# Backup con timestamp
bak = Path(f"wrap_core.py.bak_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
bak.write_text(src, encoding="utf-8")
print("Backup creado:", bak.name)

lines = src.splitlines()

# --- 1) Eliminar bloque industrial roto (si existe) ---
# Borra desde cualquier línea que contenga "Exportación industrial" o "EXPORTACIÓN INDUSTRIAL"
# hasta el siguiente "except" (incluido) o hasta que termine un bloque indentado similar.
out = []
i = 0
removed = 0
while i < len(lines):
    line = lines[i]
    if ("Exportación industrial" in line) or ("EXPORTACIÓN INDUSTRIAL" in line):
        removed += 1
        # saltar hasta encontrar un except alineado o una línea que parezca fin del bloque
        i += 1
        while i < len(lines):
            if re.match(r"^\s*except\b", lines[i]):
                i += 1
                # también salta posibles 'pass' / prints del except
                while i < len(lines) and (lines[i].strip()=="" or re.match(r"^\s*(pass|print)\b", lines[i])):
                    i += 1
                break
            # si encuentra un "if st.button" o "if st." a nivel similar, cortar
            if re.match(r"^\s*if\s+st\.", lines[i]):
                break
            i += 1
        continue

    out.append(line)
    i += 1

new = "\n".join(out) + "\n"

# --- 2) Asegurar imports ---
if "from datetime import datetime" not in new:
    new = new.replace("import pandas as pd\n", "import pandas as pd\nfrom datetime import datetime\n", 1)

if "from exports_industrial import" not in new and "exports_industrial" in (Path(".").read_text if False else ""):
    pass

if "from exports_industrial import export_full_workbook" not in new:
    new = new.replace(
        "from logistat_engine import run_logistat_v11, RULES\n",
        "from logistat_engine import run_logistat_v11, RULES\n"
        "from exports_industrial import export_full_workbook, export_single_sheet, list_schema_sheets\n",
        1
    )

# --- 3) Insertar bloque correcto después de out_xlsx ---
anchor = 'st.session_state["out_xlsx"] = result.get("plan_excel")'
pos = new.find(anchor)
if pos == -1:
    raise SystemExit("No encontré la línea: st.session_state['out_xlsx'] = result.get('plan_excel')")

# Detectar indentación del anchor
line_start = new.rfind("\n", 0, pos) + 1
indent = re.match(r"[ \t]*", new[line_start:pos]).group(0)

block = f"""
{indent}# Exportación industrial (hojas por separado + workbook completo)
{indent}try:
{indent}    out_dir = os.path.join(base_dir, "OUTPUT")
{indent}    os.makedirs(out_dir, exist_ok=True)
{indent}    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

{indent}    # Workbook completo
{indent}    full_path = os.path.join(out_dir, f"LOGISTAT_EXPORT_COMPLETO_{{stamp}}.xlsx")
{indent}    if isinstance(st.session_state.get("out_xlsx"), str) and os.path.exists(st.session_state["out_xlsx"]):
{indent}        export_full_workbook(st.session_state["out_xlsx"], full_path)
{indent}        st.session_state["out_full_export"] = full_path

{indent}        # Individuales
{indent}        indiv = {{}}
{indent}        for sh in list_schema_sheets():
{indent}            pth = os.path.join(out_dir, f"{{sh}}_EXPORT_{{stamp}}.xlsx")
{indent}            export_single_sheet(st.session_state["out_xlsx"], sh, pth)
{indent}            indiv[sh] = pth
{indent}        st.session_state["out_sheet_exports"] = indiv
{indent}except Exception as e:
{indent}    print("Error exportación industrial:", e)
"""

if "out_full_export" not in new:
    new = new.replace(anchor, anchor + "\n" + block, 1)

p.write_text(new, encoding="utf-8")
print("wrap_core.py corregido. Bloques removidos:", removed)
