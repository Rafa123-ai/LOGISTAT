from pathlib import Path

REPL = {
    "PlaneaciÃ³n":"Planeación",
    "DiÃ©sel":"Diésel",
    "ExportaciÃ³n":"Exportación",
    "â€“":"–",
    "â€”":"—",
    "mÂ³":"m³",
    "Ã¡":"á","Ã©":"é","Ã­":"í","Ã³":"ó","Ãº":"ú",
    "Ã":"Á","Ã‰":"É","Ã":"Í","Ã“":"Ó","Ãš":"Ú",
    "Ã±":"ñ","Ã‘":"Ñ",
    "â€˜":"‘","â€™":"’","â€œ":"“","â€�":"”","â€¦":"…",
    "Â":""
}

def fix_text(s: str) -> str:
    for a,b in REPL.items():
        s = s.replace(a,b)
    return s

root = Path(".")
files = list(root.rglob("*.py")) + list(root.rglob("*.txt")) + list(root.rglob("*.md"))

changed = 0
for p in files:
    try:
        txt = p.read_text(encoding="utf-8", errors="replace")
        new = fix_text(txt)
        if new != txt:
            p.write_text(new, encoding="utf-8", newline="\n")
            print("FIX:", p)
            changed += 1
    except Exception as e:
        print("SKIP:", p, e)

print(f"\nArchivos modificados: {changed}")
